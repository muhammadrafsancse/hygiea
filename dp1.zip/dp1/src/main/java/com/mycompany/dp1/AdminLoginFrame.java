package com.mycompany.dp1;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;

public class AdminLoginFrame extends JFrame {

    public AdminLoginFrame() {
        setTitle("Authority Login");
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);
        setSize(420, 280);
        setLocationRelativeTo(null);

        JPanel content = new JPanel(new BorderLayout(0, 18));
        content.setBorder(new EmptyBorder(20, 20, 20, 20));
        content.setBackground(UIHelper.BACKGROUND_COLOR);

        JLabel title = UIHelper.createHeader("Authority Sign-In");
        title.setHorizontalAlignment(SwingConstants.CENTER);
        content.add(title, BorderLayout.NORTH);

        JPanel form = new JPanel(new GridBagLayout());
        form.setOpaque(false);
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 0, 10, 0);
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.gridx = 0;
        gbc.gridy = 0;

        JLabel usernameLabel = UIHelper.createLabel("Admin Username");
        JTextField username = new JTextField();
        UIHelper.styleField(username);
        form.add(usernameLabel, gbc);
        gbc.gridy++;
        form.add(username, gbc);

        JLabel passwordLabel = UIHelper.createLabel("Admin Password");
        JPasswordField password = new JPasswordField();
        UIHelper.styleField(password);
        gbc.gridy++;
        form.add(passwordLabel, gbc);
        gbc.gridy++;
        form.add(password, gbc);

        JButton loginBtn = new JButton("Login");
        UIHelper.styleButton(loginBtn);
        gbc.gridy++;
        form.add(loginBtn, gbc);

        content.add(form, BorderLayout.CENTER);

        loginBtn.addActionListener(e -> {
            String enteredUser = username.getText();
            String enteredPass = new String(password.getPassword());

            if (enteredUser.equals(AdminAuth.USERNAME) && enteredPass.equals(AdminAuth.PASSWORD)) {
                JOptionPane.showMessageDialog(this, "Authority Login Successful");
                new AuthorityDashboard();
                dispose();
            } else {
                JOptionPane.showMessageDialog(this, "Invalid Authority Credentials");
            }
        });

        setContentPane(content);
        setVisible(true);
    }
}