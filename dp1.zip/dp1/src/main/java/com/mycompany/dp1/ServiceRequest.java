
package com.mycompany.dp1;

/**
 *
 * @author LENOVO
 */
public class ServiceRequest {
    int id;
    String username, service, status, description, location, contact;

    public ServiceRequest(int id, String username, String service, String status) {
        this.id = id;
        this.username = username;
        this.service = service;
        this.status = status;
        this.description = "";
        this.location = "";
        this.contact = "";
    }

    public ServiceRequest(int id, String username, String service, String status, String description, String location, String contact) {
        this.id = id;
        this.username = username;
        this.service = service;
        this.status = status;
        this.description = description;
        this.location = location;
        this.contact = contact;
    }
}
