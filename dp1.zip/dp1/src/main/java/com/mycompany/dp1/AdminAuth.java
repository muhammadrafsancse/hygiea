
package com.mycompany.dp1;

/**
 *
 * @author LENOVO
 */
public class AdminAuth {
    public static final String USERNAME = "admin";
    public static final String PASSWORD = "1234";
}
