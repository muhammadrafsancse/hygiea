package com.mycompany.dp1;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class FileManager {
    public static void saveUser(String username, String password) throws IOException {
        BufferedWriter bw = new BufferedWriter(new FileWriter("users.txt", true));
        bw.write(username + "," + password);
        bw.newLine();
        bw.close();
    }

    public static boolean validateUser(String username, String password) throws IOException {
        File file = new File("users.txt");
        if(!file.exists()) return false;
        BufferedReader br = new BufferedReader(new FileReader(file));
        String line;
        while((line = br.readLine()) != null){
            String[] data = line.split(",");
            if(data[0].equals(username) && data[1].equals(password)){
                br.close();
                return true;
            }
        }
        br.close();
        return false;
    }

    public static void saveRequest(ServiceRequest req) throws IOException {
        BufferedWriter bw = new BufferedWriter(new FileWriter("requests.txt", true));
        bw.write(req.id + "," + req.username + "," + req.service + "," + req.status + "," + req.description + "," + req.location + "," + req.contact);
        bw.newLine();
        bw.close();
    }

    public static List<ServiceRequest> getUserRequests(String username) throws IOException {
        List<ServiceRequest> requests = new ArrayList<>();
        File file = new File("requests.txt");
        if (!file.exists()) return requests;
        BufferedReader br = new BufferedReader(new FileReader(file));
        String line;
        while ((line = br.readLine()) != null) {
            String[] data = line.split(",");
            if (data.length >= 4 && data[1].equals(username)) {
                String description = data.length > 4 ? data[4] : "";
                String location = data.length > 5 ? data[5] : "";
                String contact = data.length > 6 ? data[6] : "";
                ServiceRequest req = new ServiceRequest(Integer.parseInt(data[0]), data[1], data[2], data[3], description, location, contact);
                requests.add(req);
            }
        }
        br.close();
        return requests;
    }

    public static List<ServiceRequest> getAllRequests() throws IOException {
        List<ServiceRequest> requests = new ArrayList<>();
        File file = new File("requests.txt");
        if (!file.exists()) return requests;
        BufferedReader br = new BufferedReader(new FileReader(file));
        String line;
        while ((line = br.readLine()) != null) {
            String[] data = line.split(",");
            if (data.length >= 4) {
                String description = data.length > 4 ? data[4] : "";
                String location = data.length > 5 ? data[5] : "";
                String contact = data.length > 6 ? data[6] : "";
                ServiceRequest req = new ServiceRequest(Integer.parseInt(data[0]), data[1], data[2], data[3], description, location, contact);
                requests.add(req);
            }
        }
        br.close();
        return requests;
    }

    public static void updateRequestStatus(int id, String newStatus) throws IOException {
        List<String> lines = new ArrayList<>();
        File file = new File("requests.txt");
        if (file.exists()) {
            BufferedReader br = new BufferedReader(new FileReader(file));
            String line;
            while ((line = br.readLine()) != null) {
                String[] data = line.split(",");
                if (data.length >= 4 && Integer.parseInt(data[0]) == id) {
                    // Update status
                    data[3] = newStatus;
                    line = String.join(",", data);
                }
                lines.add(line);
            }
            br.close();
        }
        BufferedWriter bw = new BufferedWriter(new FileWriter(file));
        for (String l : lines) {
            bw.write(l);
            bw.newLine();
        }
        bw.close();
    }
}   

