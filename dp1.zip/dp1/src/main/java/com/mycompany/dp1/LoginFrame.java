package com.mycompany.dp1;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;

public class LoginFrame extends JFrame {
    public LoginFrame() {
        setTitle("Hygiea Portal");
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setSize(460, 340);
        setLocationRelativeTo(null);

        JPanel content = new JPanel(new BorderLayout(0, 24));
        content.setBorder(new EmptyBorder(24, 24, 24, 24));
        content.setBackground(UIHelper.BACKGROUND_COLOR);

        JLabel title = UIHelper.createHeader("Hygiea");
        title.setHorizontalAlignment(SwingConstants.CENTER);
        content.add(title, BorderLayout.NORTH);

        JPanel buttons = new JPanel(new GridLayout(3, 1, 0, 16));
        buttons.setOpaque(false);

        JButton userLogin = new JButton("User Login");
        JButton register = new JButton("Register");
        JButton adminLogin = new JButton("Authority Login");

        UIHelper.styleButton(userLogin);
        UIHelper.styleButton(register);
        UIHelper.styleButton(adminLogin);

        buttons.add(userLogin);
        buttons.add(register);
        buttons.add(adminLogin);

        content.add(buttons, BorderLayout.CENTER);

        userLogin.addActionListener(e -> new UserLoginFrame());
        register.addActionListener(e -> new RegisterFrame());
        adminLogin.addActionListener(e -> new AdminLoginFrame());

        setContentPane(content);
        setVisible(true);
    }
}