
package com.mycompany.dp1;

/**
 *
 * @author LENOVO
 */
public class User {
    String username, password;
    public User(String username, String password){
        this.username = username;
        this.password = password;   
}
}
