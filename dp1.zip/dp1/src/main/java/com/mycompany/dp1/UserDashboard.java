package com.mycompany.dp1;

import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.util.List;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.SwingConstants;
import javax.swing.border.EmptyBorder;

public class UserDashboard extends JFrame {
    private String username;

    public UserDashboard(String username) {
        this.username = username;
        setTitle("Hygiea Dashboard");
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);
        setSize(560, 520);
        setLocationRelativeTo(null);

        JPanel content = new JPanel(new BorderLayout(0, 20));
        content.setBorder(new EmptyBorder(24, 24, 24, 24));
        content.setBackground(UIHelper.BACKGROUND_COLOR);

        JLabel title = UIHelper.createHeader("Hello, " + username);
        title.setHorizontalAlignment(SwingConstants.LEFT);
        content.add(title, BorderLayout.NORTH);

        JPanel servicesPanel = new JPanel(new GridLayout(3, 2, 18, 18));
        servicesPanel.setOpaque(false);
        servicesPanel.setBorder(new EmptyBorder(10, 0, 0, 0));

        String[] services = {
            "Pest Control", "Water Supply", "Clean Water",
            "Drainage System", "Garbage Collection", "Complaint"
        };

        for (String service : services) {
            JButton btn = new JButton(service);
            UIHelper.styleButton(btn);
            btn.addActionListener(e -> handleServiceRequest(service));
            servicesPanel.add(btn);
        }

        content.add(servicesPanel, BorderLayout.CENTER);

        JButton viewStatusBtn = new JButton("View Status");
        UIHelper.styleButton(viewStatusBtn);
        viewStatusBtn.addActionListener(e -> viewStatus());
        JPanel bottomPanel = new JPanel(new FlowLayout(FlowLayout.CENTER));
        bottomPanel.setOpaque(false);
        bottomPanel.add(viewStatusBtn);
        content.add(bottomPanel, BorderLayout.SOUTH);

        setContentPane(content);
        setVisible(true);
    }

    private void handleServiceRequest(String service) {
        if ("Complaint".equals(service)) {
            JTextArea textArea = new JTextArea(5, 30);
            UIHelper.styleField(textArea);
            JScrollPane scrollPane = new JScrollPane(textArea);
            int result = JOptionPane.showConfirmDialog(this, scrollPane, "Describe your complaint", JOptionPane.OK_CANCEL_OPTION);
            if (result == JOptionPane.OK_OPTION) {
                String description = textArea.getText().trim();
                if (!description.isEmpty()) {
                    try {
                        int id = (int) (System.currentTimeMillis() % 100000);
                        FileManager.saveRequest(new ServiceRequest(id, username, service, "Pending", description, "", ""));
                        JOptionPane.showMessageDialog(this, "Complaint Submitted");
                    } catch (Exception ex) {
                        JOptionPane.showMessageDialog(this, "Request Failed");
                    }
                }
            }
        } else {
            JTextField locationField = new JTextField();
            UIHelper.styleField(locationField);
            JTextField contactField = new JTextField();
            UIHelper.styleField(contactField);

            JPanel panel = new JPanel(new GridLayout(2, 2, 5, 5));
            panel.setBackground(UIHelper.BACKGROUND_COLOR);
            panel.add(UIHelper.createLabel("Location:"));
            panel.add(locationField);
            panel.add(UIHelper.createLabel("Contact:"));
            panel.add(contactField);

            int result = JOptionPane.showConfirmDialog(this, panel, service + " Request", JOptionPane.OK_CANCEL_OPTION);
            if (result == JOptionPane.OK_OPTION) {
                String location = locationField.getText().trim();
                String contact = contactField.getText().trim();
                if (!location.isEmpty() && !contact.isEmpty()) {
                    try {
                        int id = (int) (System.currentTimeMillis() % 100000);
                        FileManager.saveRequest(new ServiceRequest(id, username, service, "Pending", "", location, contact));
                        JOptionPane.showMessageDialog(this, service + " Requested");
                    } catch (Exception ex) {
                        JOptionPane.showMessageDialog(this, "Request Failed");
                    }
                } else {
                    JOptionPane.showMessageDialog(this, "Please fill all fields");
                }
            }
        }
    }

    private void viewStatus() {
        try {
            List<ServiceRequest> requests = FileManager.getUserRequests(username);
            if (requests.isEmpty()) {
                JOptionPane.showMessageDialog(this, "No requests found");
                return;
            }
            StringBuilder sb = new StringBuilder();
            for (ServiceRequest req : requests) {
                sb.append("ID: ").append(req.id).append(" - ").append(req.service).append(" - ").append(req.status).append("\n");
            }
            JTextArea textArea = new JTextArea(sb.toString());
            textArea.setEditable(false);
            UIHelper.styleField(textArea);
            JScrollPane scrollPane = new JScrollPane(textArea);
            JOptionPane.showMessageDialog(this, scrollPane, "Your Requests", JOptionPane.INFORMATION_MESSAGE);
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, "Failed to load requests");
        }
    }
}