
package com.mycompany.dp1;

import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.util.List;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.SwingConstants;
import javax.swing.border.EmptyBorder;

public class AuthorityDashboard extends JFrame {
    private final JTextArea area;

    public AuthorityDashboard() {
        setTitle("Authority Dashboard");
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);
        setSize(620, 520);
        setLocationRelativeTo(null);

        JPanel content = new JPanel(new BorderLayout(0, 18));
        content.setBorder(new EmptyBorder(22, 22, 22, 22));
        content.setBackground(UIHelper.BACKGROUND_COLOR);

        JLabel title = UIHelper.createHeader("Authority Requests");
        title.setHorizontalAlignment(SwingConstants.LEFT);
        content.add(title, BorderLayout.NORTH);

        area = new JTextArea();
        area.setEditable(false);
        area.setBackground(UIHelper.CARD_COLOR);
        area.setForeground(UIHelper.TEXT_COLOR);
        area.setFont(UIHelper.DEFAULT_FONT);
        area.setLineWrap(true);
        area.setWrapStyleWord(true);
        area.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(UIHelper.LINE_COLOR, 1),
            new EmptyBorder(12, 12, 12, 12)
        ));

        JButton refresh = new JButton("Refresh Requests");
        UIHelper.styleButton(refresh);
        refresh.addActionListener(e -> loadRequests());

        JButton updateStatus = new JButton("Update Status");
        UIHelper.styleButton(updateStatus);
        updateStatus.addActionListener(e -> updateStatusDialog());

        content.add(new JScrollPane(area), BorderLayout.CENTER);
        JPanel bottom = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        bottom.setOpaque(false);
        bottom.add(refresh);
        bottom.add(updateStatus);
        content.add(bottom, BorderLayout.SOUTH);

        setContentPane(content);
        loadRequests();
        setVisible(true);
    }

    private void loadRequests() {
        try {
            List<ServiceRequest> requests = FileManager.getAllRequests();
            area.setText("");
            for (ServiceRequest req : requests) {
                area.append("ID: " + req.id + " - User: " + req.username + " - Service: " + req.service + " - Status: " + req.status);
                if (!req.description.isEmpty()) {
                    area.append(" - Desc: " + req.description);
                }
                if (!req.location.isEmpty()) {
                    area.append(" - Loc: " + req.location);
                }
                if (!req.contact.isEmpty()) {
                    area.append(" - Contact: " + req.contact);
                }
                area.append("\n");
            }
        } catch (Exception ex) {
            area.setText("No Requests Found");
        }
    }

    private void updateStatusDialog() {
        try {
            List<ServiceRequest> requests = FileManager.getAllRequests();
            if (requests.isEmpty()) {
                showMessageDialog("No requests to update");
                return;
            }
            String[] ids = new String[requests.size()];
            for (int i = 0; i < requests.size(); i++) {
                ids[i] = String.valueOf(requests.get(i).id);
            }

            JComboBox<String> idCombo = new JComboBox<>(ids);
            styleComboBox(idCombo);
            JComboBox<String> statusCombo = new JComboBox<>(new String[]{"Pending", "Ongoing", "Completed"});
            styleComboBox(statusCombo);

            JPanel panel = new JPanel(new BorderLayout(10, 10));
            panel.setBackground(UIHelper.BACKGROUND_COLOR);
            panel.setBorder(new EmptyBorder(20, 20, 20, 20));

            JPanel idPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
            idPanel.setBackground(UIHelper.BACKGROUND_COLOR);
            idPanel.add(UIHelper.createLabel("Select Request ID:"));
            idPanel.add(idCombo);

            JPanel statusPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
            statusPanel.setBackground(UIHelper.BACKGROUND_COLOR);
            statusPanel.add(UIHelper.createLabel("Select New Status:"));
            statusPanel.add(statusCombo);

            panel.add(idPanel, BorderLayout.NORTH);
            panel.add(statusPanel, BorderLayout.CENTER);

            JButton updateBtn = new JButton("Update");
            UIHelper.styleButton(updateBtn);
            JButton cancelBtn = new JButton("Cancel");
            UIHelper.styleButton(cancelBtn);

            JPanel buttonPanel = new JPanel(new FlowLayout());
            buttonPanel.setBackground(UIHelper.BACKGROUND_COLOR);
            buttonPanel.add(updateBtn);
            buttonPanel.add(cancelBtn);

            panel.add(buttonPanel, BorderLayout.SOUTH);

            JDialog dialog = new JDialog(this, "Update Status", true);
            dialog.setContentPane(panel);
            dialog.pack();
            dialog.setLocationRelativeTo(this);

            updateBtn.addActionListener(e -> {
                String selectedId = (String) idCombo.getSelectedItem();
                String newStatus = (String) statusCombo.getSelectedItem();
                try {
                    FileManager.updateRequestStatus(Integer.parseInt(selectedId), newStatus);
                    loadRequests();
                    showMessageDialog("Status Updated");
                } catch (Exception ex) {
                    showMessageDialog("Update Failed");
                }
                dialog.dispose();
            });

            cancelBtn.addActionListener(e -> dialog.dispose());

            dialog.setVisible(true);

        } catch (Exception ex) {
            showMessageDialog("Update Failed");
        }
    }

    private void showMessageDialog(String message) {
        JTextArea textArea = new JTextArea(message);
        textArea.setEditable(false);
        UIHelper.styleField(textArea);
        JScrollPane scrollPane = new JScrollPane(textArea);
        scrollPane.setPreferredSize(new java.awt.Dimension(300, 100));

        JPanel panel = new JPanel(new BorderLayout());
        panel.setBackground(UIHelper.BACKGROUND_COLOR);
        panel.add(scrollPane, BorderLayout.CENTER);

        JButton okBtn = new JButton("OK");
        UIHelper.styleButton(okBtn);
        JPanel buttonPanel = new JPanel(new FlowLayout());
        buttonPanel.setBackground(UIHelper.BACKGROUND_COLOR);
        buttonPanel.add(okBtn);
        panel.add(buttonPanel, BorderLayout.SOUTH);

        JDialog dialog = new JDialog(this, "Message", true);
        dialog.setContentPane(panel);
        dialog.pack();
        dialog.setLocationRelativeTo(this);

        okBtn.addActionListener(e -> dialog.dispose());

        dialog.setVisible(true);
    }

    private void styleComboBox(JComboBox<String> combo) {
        combo.setBackground(UIHelper.CARD_COLOR);
        combo.setForeground(UIHelper.TEXT_COLOR);
        combo.setFont(UIHelper.DEFAULT_FONT);
    }
}
