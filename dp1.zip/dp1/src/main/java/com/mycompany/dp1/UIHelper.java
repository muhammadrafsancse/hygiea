package com.mycompany.dp1;

import java.awt.Color;
import java.awt.Font;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPasswordField;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.UIManager;
import javax.swing.border.EmptyBorder;

public final class UIHelper {
    public static final Color BACKGROUND_COLOR = new Color(18, 28, 52);
    public static final Color CARD_COLOR = new Color(32, 43, 74);
    public static final Color BUTTON_COLOR = new Color(74, 144, 226);
    public static final Color BUTTON_HOVER = new Color(94, 164, 246);
    public static final Color TEXT_COLOR = new Color(240, 244, 255);
    public static final Color LINE_COLOR = new Color(102, 120, 150);
    public static final Font HEADER_FONT = new Font("Segoe UI", Font.BOLD, 26);
    public static final Font DEFAULT_FONT = new Font("Segoe UI", Font.PLAIN, 14);

    private UIHelper() {
        // utility only
    }

    public static void initModernTheme() {
        try {
            for (UIManager.LookAndFeelInfo info : UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (Exception ignored) {
            // fallback to default
        }

        UIManager.put("control", BACKGROUND_COLOR);
        UIManager.put("info", CARD_COLOR);
        UIManager.put("nimbusBase", new Color(34, 45, 72));
        UIManager.put("nimbusFocus", new Color(120, 170, 230));
        UIManager.put("nimbusSelectedText", TEXT_COLOR);
        UIManager.put("nimbusSelectionBackground", BUTTON_HOVER);
        UIManager.put("text", TEXT_COLOR);
        UIManager.put("Button.background", BUTTON_COLOR);
        UIManager.put("Button.foreground", TEXT_COLOR);
        UIManager.put("Button.select", BUTTON_HOVER);
        UIManager.put("Panel.background", BACKGROUND_COLOR);
        UIManager.put("Label.font", DEFAULT_FONT);
        UIManager.put("Button.font", DEFAULT_FONT);
        UIManager.put("TextField.font", DEFAULT_FONT);
        UIManager.put("PasswordField.font", DEFAULT_FONT);
    }

    public static void styleButton(JButton button) {
        button.setBackground(BUTTON_COLOR);
        button.setForeground(TEXT_COLOR);
        button.setFont(DEFAULT_FONT.deriveFont(Font.BOLD));
        button.setFocusPainted(false);
        button.setBorder(BorderFactory.createEmptyBorder(12, 20, 12, 20));
        button.setOpaque(true);
    }

    public static void styleField(JTextField field) {
        field.setBackground(new Color(236, 242, 255));
        field.setForeground(Color.BLACK);
        field.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(LINE_COLOR, 1),
            new EmptyBorder(8, 10, 8, 10)
        ));
        field.setFont(DEFAULT_FONT);
    }

    public static void styleField(JPasswordField field) {
        field.setBackground(new Color(236, 242, 255));
        field.setForeground(Color.BLACK);
        field.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(LINE_COLOR, 1),
            new EmptyBorder(8, 10, 8, 10)
        ));
        field.setFont(DEFAULT_FONT);
    }

    public static void styleField(JTextArea field) {
        field.setBackground(new Color(236, 242, 255));
        field.setForeground(Color.BLACK);
        field.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(LINE_COLOR, 1),
            new EmptyBorder(8, 10, 8, 10)
        ));
        field.setFont(DEFAULT_FONT);
    }
    public static void styleLabel(JLabel label) {
        label.setForeground(TEXT_COLOR);
        label.setFont(DEFAULT_FONT);
    }

    public static JLabel createLabel(String text) {
        JLabel label = new JLabel(text);
        styleLabel(label);
        return label;
    }

    public static JLabel createHeader(String text) {
        JLabel label = new JLabel(text);
        label.setFont(HEADER_FONT);
        label.setForeground(TEXT_COLOR);
        return label;
    }
}
