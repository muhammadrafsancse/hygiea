package com.mycompany.dp1;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;

public class RegisterFrame extends JFrame {
    public RegisterFrame() {
        setTitle("Register");
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);
        setSize(420, 260);
        setLocationRelativeTo(null);

        JPanel content = new JPanel(new BorderLayout(0, 18));
        content.setBorder(new EmptyBorder(20, 20, 20, 20));
        content.setBackground(UIHelper.BACKGROUND_COLOR);

        JLabel title = UIHelper.createHeader("Create Account");
        title.setHorizontalAlignment(SwingConstants.CENTER);
        content.add(title, BorderLayout.NORTH);

        JPanel form = new JPanel(new GridBagLayout());
        form.setOpaque(false);
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 0, 10, 0);
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.gridx = 0;
        gbc.gridy = 0;

        JLabel usernameLabel = UIHelper.createLabel("Username");
        JTextField username = new JTextField();
        UIHelper.styleField(username);
        form.add(usernameLabel, gbc);
        gbc.gridy++;
        form.add(username, gbc);

        JLabel passwordLabel = UIHelper.createLabel("Password");
        JPasswordField password = new JPasswordField();
        UIHelper.styleField(password);
        gbc.gridy++;
        form.add(passwordLabel, gbc);
        gbc.gridy++;
        form.add(password, gbc);

        JButton registerBtn = new JButton("Register");
        UIHelper.styleButton(registerBtn);
        gbc.gridy++;
        form.add(registerBtn, gbc);

        content.add(form, BorderLayout.CENTER);

        registerBtn.addActionListener(e -> {
            try {
                FileManager.saveUser(username.getText(), new String(password.getPassword()));
                JOptionPane.showMessageDialog(this, "Registered Successfully");
                dispose();
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(this, "Error Registering User");
            }
        });

        setContentPane(content);
        setVisible(true);
    }
}